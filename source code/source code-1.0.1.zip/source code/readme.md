This folder contain the source code of the addon version avaliable in this repository.
